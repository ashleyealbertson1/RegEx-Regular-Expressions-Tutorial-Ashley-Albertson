const grades = [56, 78, 99, 85];

// TODO: Complete the 'findAverage' function below.
function findAverage(accumalator, currentValue, index, array) {
    
}

// TODO: Pass the 'findAverage' into the reduce method.
let gradeAverage = grades.reduce();

console.log(gradeAverage);
