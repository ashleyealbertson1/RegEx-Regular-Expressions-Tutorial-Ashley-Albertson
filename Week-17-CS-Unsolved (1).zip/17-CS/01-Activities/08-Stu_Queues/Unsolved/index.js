// create the Queue class with two methods to remove and add an element
class Queue {
  
}

module.exports = Queue;
