#!/bin/bash

# print "Hello World!" to the command line 
echo "============"
echo "Hello World!"
echo "============"
