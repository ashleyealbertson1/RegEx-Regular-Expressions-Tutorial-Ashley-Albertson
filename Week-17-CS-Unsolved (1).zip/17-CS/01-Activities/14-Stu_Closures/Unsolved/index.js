// TODO: Complete the 'counter' function below.
function counter() {}

module.exports = counter;
